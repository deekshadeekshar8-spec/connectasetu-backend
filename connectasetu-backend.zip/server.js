/**
 * ConnectASetu - Secure Backend (Supabase Version)
 * Strict Team-Locked RBAC + Supabase + Gemini AI
 */

import express from "express";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import { createClient } from "@supabase/supabase-js";
import { GoogleGenAI } from "@google/genai";
import cors from "cors";

dotenv.config();

/* =============================
   EXPRESS APP INIT (ONLY ONCE)
============================= */

const app = express();

app.use(express.json());
app.use(
  cors({
    origin: "http://localhost:5173", // Vite frontend
    credentials: true,
  })
);

/* =============================
   ENV VARIABLES
============================= */

const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET;

/* =============================
   SUPABASE INITIALIZATION
============================= */

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

/* =============================
   GEMINI INITIALIZATION
============================= */

const ai = new GoogleGenAI({
  apiKey: process.env.API_KEY,
});

/* =============================
   AUTH MIDDLEWARE
============================= */

const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) return res.status(401).json({ message: "Unauthorized" });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ message: "Invalid Token" });
  }
};

/* =============================
   LOGIN ROUTE
============================= */

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;

  const { data: user, error } = await supabase
    .from("users")
    .select("*")
    .eq("email", email)
    .single();

  if (error || !user)
    return res.status(400).json({ message: "User not found" });

  if (user.password !== password)
    return res.status(400).json({ message: "Invalid credentials" });

  const token = jwt.sign(
    {
      id: user.id,
      role: user.role,
      team: user.team,
      name: user.name,
    },
    JWT_SECRET,
    { expiresIn: "1d" }
  );

  res.json({ token });
});

/* =============================
   GET CONTACTS (RBAC)
============================= */

app.get("/api/contacts", authenticate, async (req, res) => {
  let query = supabase.from("contacts").select("*");

  if (req.user.role !== "super_admin") {
    query = query.eq("assigned_team_id", req.user.team);

    if (req.user.role.includes("employee")) {
      query = query.eq("assigned_employee_id", req.user.id);
    }
  }

  const { data, error } = await query.order("created_at", {
    ascending: false,
  });

  if (error) return res.status(500).json({ message: error.message });

  res.json(data);
});

/* =============================
   CREATE CONTACT
============================= */

app.post("/api/contacts", authenticate, async (req, res) => {
  const { name, phone, email, source } = req.body;

  const { data: existing } = await supabase
    .from("contacts")
    .select("*")
    .eq("phone", phone)
    .single();

  if (existing) return res.json(existing);

  const { data, error } = await supabase.from("contacts").insert([
    {
      name,
      phone,
      email,
      source,
      assigned_team_id: req.user.team,
      created_by_team_id: req.user.team,
      assigned_employee_id: req.user.id,
      status: "New",
    },
  ]);

  if (error) return res.status(500).json({ message: error.message });

  res.status(201).json(data);
});

/* =============================
   CALL RECORDING ACCESS
============================= */

app.get("/api/calls/:id/recording", authenticate, async (req, res) => {
  const { data: call, error } = await supabase
    .from("calls")
    .select("*")
    .eq("id", req.params.id)
    .single();

  if (error || !call)
    return res.status(404).json({ message: "Not found" });

  const isSuper = req.user.role === "super_admin";
  const sameTeam = call.employee_team === req.user.team;

  if (!isSuper && !sameTeam)
    return res.status(403).json({ message: "Forbidden" });

  if (isSuper || call.recording_consent)
    return res.json({ url: call.recording_url });

  res.status(403).json({ message: "Consent required" });
});

/* =============================
   GEMINI AI ASSISTANT
============================= */

app.post("/api/assistant/message", authenticate, async (req, res) => {
  const { message, currentPage } = req.body;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-1.5-flash",
      contents: `CRM Context:
Role: ${req.user.role}
Team: ${req.user.team}
Page: ${currentPage}
Question: ${message}`,
    });

    res.json({ reply: response.text });
  } catch {
    res.status(500).json({
      reply: "Assistant temporarily unavailable.",
    });
  }
});

/* =============================
   SERVER START
============================= */
app.get("/", (req, res) => {
  res.send("✅ Supabase Backend Running Successfully");
});
app.listen(PORT, () =>
  console.log(`🚀 Supabase Backend running on port ${PORT}`)
);